#!/bin/bash

# ==============================================================================
# FILE: /usr/local/sbin/grouping_map.sh
# FUNGSI: Logika mapping nama domain super agresif dan fungsi lookup
# ==============================================================================

group_name() {
    local name="$1"
    name=$(echo "$name" | tr '[:upper:]' '[:lower:]')
    
    if echo "$name" | grep -qE 'google|youtube|ytimg|ggpht|gstatic|1e100'; then echo "google.com"; return; fi
    if echo "$name" | grep -qE 'facebook|fbcdn|fbsbx|whatsapp|instagram'; then echo "facebook.com"; return; fi
    if echo "$name" | grep -qE 'tiktok|bytedance'; then echo "tiktok.com"; return; fi
    if echo "$name" | grep -qE 'amazon|aws'; then echo "aws.amazon.com"; return; fi
    if echo "$name" | grep -qE 'cloudflare'; then echo "cloudflare.com"; return; fi
    if echo "$name" | grep -qE 'akamai'; then echo "akamai.net"; return; fi
    if echo "$name" | grep -qE 'digitalocean'; then echo "digitalocean.com"; return; fi
    if echo "$name" | grep -qE 'biznet'; then echo "biznetnetworks.com"; return; fi
    if echo "$name" | grep -qE 'netflix'; then echo "netflix.com"; return; fi
    if echo "$name" | grep -qE 'microsoft|azure'; then echo "microsoft.com"; return; fi
    if echo "$name" | grep -qE 'apple'; then echo "apple.com"; return; fi
    if echo "$name" | grep -qE 'telegram'; then echo "telegram.org"; return; fi
    if echo "$name" | grep -qE 'twitter|twimg|x\.com'; then echo "twitter.com"; return; fi
    if echo "$name" | grep -qE 'spotify'; then echo "spotify.com"; return; fi
    if echo "$name" | grep -qE 'one\.one\.one\.one|dns\.google|8\.8\.8\.8|1\.1\.1\.1|1\.0\.0\.1'; then echo "dns-server"; return; fi

    echo "$name" | awk -F'.' '{
        if (NF > 2) {
            if (length($(NF-1)) <= 3 && length($NF) <= 3) {
                if (NF > 3) print $(NF-2)"."$(NF-1)"."$NF
                else print $0
            } else {
                print $(NF-1)"."$NF
            }
        } else {
            print $0
        }
    }'
}

lookup_ip_external() {
    local ip="$1"
    local result=$(curl -s "https://ipinfo.io/$ip/json" | jq -r '.hostname // .org // .city // "unknown"' 2>/dev/null)
    if [ -z "$result" ] || [ "$result" = "null" ]; then
        result="unknown"
    fi
    echo "$result"
}

get_cached_or_lookup_grouped() {
    local ip="$1"
    local cached_name=""
    if [ $SQLITE_AVAILABLE -eq 1 ]; then
        cached_name=$(sqlite3 "$DB_FILE" "SELECT name FROM ip_cache WHERE ip='$ip';" 2>/dev/null)
    fi
    if [ -n "$cached_name" ]; then
        echo "$cached_name"
        return 0
    fi
    local raw_name=$(lookup_ip_external "$ip")
    local grouped=$(group_name "$raw_name")
    if [ $SQLITE_AVAILABLE -eq 1 ] && [ -n "$grouped" ] && [ "$grouped" != "unknown" ]; then
        sqlite3 "$DB_FILE" "INSERT OR REPLACE INTO ip_cache (ip, name, created_at) VALUES ('$ip', '$grouped', strftime('%s','now'));" 2>/dev/null
    fi
    echo "$grouped"
}

export AWK_GROUP_FUNCS='
function group_domain(domain) {
    dom = tolower(domain)
    if (dom ~ /google|youtube|ytimg|ggpht|gstatic|1e100/) return "google.com"
    if (dom ~ /facebook|fbcdn|fbsbx|whatsapp|instagram/) return "facebook.com"
    if (dom ~ /tiktok|bytedance/) return "tiktok.com"
    if (dom ~ /amazon|aws/) return "aws.amazon.com"
    if (dom ~ /cloudflare/) return "cloudflare.com"
    if (dom ~ /akamai/) return "akamai.net"
    if (dom ~ /digitalocean/) return "digitalocean.com"
    if (dom ~ /biznet/) return "biznetnetworks.com"
    if (dom ~ /netflix/) return "netflix.com"
    if (dom ~ /microsoft|azure/) return "microsoft.com"
    if (dom ~ /apple/) return "apple.com"
    if (dom ~ /telegram/) return "telegram.org"
    if (dom ~ /twitter|twimg|x\.com/) return "twitter.com"
    if (dom ~ /spotify/) return "spotify.com"
    if (dom ~ /one\.one\.one\.one|dns\.google|8\.8\.8\.8|1\.1\.1\.1|1\.0\.0\.1/) return "dns-server"

    n = split(dom, parts, ".")
    if (n > 2) {
        if (length(parts[n-1]) <= 3 && length(parts[n]) <= 3) {
            if (n > 3) return parts[n-2] "." parts[n-1] "." parts[n]
            return dom
        }
        return parts[n-1] "." parts[n]
    }
    return dom
}
'